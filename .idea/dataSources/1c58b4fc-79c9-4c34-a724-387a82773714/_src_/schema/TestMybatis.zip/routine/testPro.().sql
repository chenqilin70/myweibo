CREATE PROCEDURE testPro()
  begin
  select * from tbl_employee where d_id in(
    select id from tbl_dept
  );

end;
